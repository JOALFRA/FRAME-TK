from Punto import *

class Figura():

    def __init__(self):
        self.area = 0
        self.perimetro = 0
        self.p1 = Punto()
        self.p2 = Punto()
