numero1 = int(input("Ingrese el primer numero: "))
numero2 = int(input("Ingrese el segundo numero: "))

suma = numero1 + numero2
resta = numero1 - numero2
producto = numero1 * numero2
division = numero1 / numero2
potencia = numero1 ** numero2

print(str(numero1) + " + " + str(numero2) + " = " + str(suma))
print(str(numero1) + " - " + str(numero2) + " = " + str(resta))
print(str(numero1) + " * " + str(numero2) + " = " + str(producto))
print(str(numero1) + " / " + str(numero2) + " = " + str(division))
print(str(numero1) + " ^ " + str(numero2) + " = " + str(potencia))
