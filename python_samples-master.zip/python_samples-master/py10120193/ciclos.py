numero = int(input("ingrese un numero"))
cont = 0
while cont <= numero:
    print (cont)
    cont += 1
    #if cont > numero:
    #    break
