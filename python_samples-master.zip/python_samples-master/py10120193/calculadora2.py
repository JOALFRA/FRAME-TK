from operaciones import *

n1 = int(input("Ingrese un numero: "))
n2 = int(input("Ingrese otro numero: "))

print("sumar(" + str(n1) + "," + str(n2) + ") = " + str(sumar(n1,n2)))
print("restar(" + str(n1) + "," + str(n2) + ") = " + str(restar(n1,n2)))
print("multiplicar(" + str(n1) + "," + str(n2) + ") = " + str(multiplicar(n1,n2)))
print("dividir(" + str(n1) + "," + str(n2) + ") = " + str(dividir(n1,n2)))
