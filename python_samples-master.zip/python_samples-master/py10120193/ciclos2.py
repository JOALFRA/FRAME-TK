numero = int(input("ingrese un numero"))

for i in range(numero + 1):
    print(i)
