numero1 = int(input("ingrese un numero a validar: "))
numero2 = int(input("ingrese un numero a validar: "))
numero3 = int(input("ingrese un numero a validar: "))

if numero1 < numero2 < numero3:
        print("estan ordenados ascendentemente")
else:
    print("no estan ordenados ascendentemente")
