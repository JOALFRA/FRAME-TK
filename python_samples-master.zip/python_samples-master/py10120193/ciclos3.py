conjunto = ['a','e','i','o','u']

for c in conjunto:
    print(c)

cont = 0

while cont < len(conjunto):
    print(conjunto[cont])
    cont += 1
