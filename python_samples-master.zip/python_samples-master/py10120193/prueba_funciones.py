from funciones import *

print(fibo2(5))
