nombre = input("ingrese su nombre: ")
print("Hola mundo en python por " + nombre)
