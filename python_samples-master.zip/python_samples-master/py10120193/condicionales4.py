conjunto = ['a','e','i','o','u']

caracter = input("ingrese un caracter: ")

if caracter in conjunto:
    print("es una vocal")
else:
    print("no es una vocal")
