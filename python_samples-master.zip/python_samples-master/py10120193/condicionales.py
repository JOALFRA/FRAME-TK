numero = int(input("ingrese un numero a validar: "))

if numero == 1:
    print("el dia es domingo")
elif numero == 2:
    print("el dia es lunes")
elif numero == 3:
    print("el dia es martes")
elif numero == 4:
    print("el dia es miercoles")
elif numero == 5:
    print("el dia es jueves")
elif numero == 6:
    print("el dia es viernes")
elif numero == 7:
    print("el dia es sabado")
else:
    print("el numero no es un dia valido")
