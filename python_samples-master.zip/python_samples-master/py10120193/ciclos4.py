lista = ['a','b','c']

for i in lista:
    print(i)

for a in range(len(lista)):
    print("en " + str(a) + " esta " + lista[a])
