from UnidadDeTiempo import *

class Minuto(UnidadDeTiempo):
	def __init__(self):
		self.valor=0
		self.tope=59
		
