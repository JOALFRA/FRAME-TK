from UnidadDeTiempo import *

class Segundo(UnidadDeTiempo):
	def __init__(self):
		self.valor=0
		self.tope=59
		
