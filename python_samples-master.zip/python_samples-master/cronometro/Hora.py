from UnidadDeTiempo import *

class Hora(UnidadDeTiempo):
	def __init__(self):
		self.valor=0
		self.tope=23
		
