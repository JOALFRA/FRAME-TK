# ejemplos de recursividad en python

1. calcular el producto de dos números mediante sumas
2. calcular la división de dos números sin dividir (restando)
3. calcular la potencia de dos números
4. calcular el término n de la serie de fibonacci
5. determinar la suma de los dígitos de un número entero positivo
6. determinar si un numero es palíndromo
7. calcular la longitud de un número entero
8. determinar el mayor digito de un número entero positivo
9. invertir un número entero positivo

# arboles binarios
1. buscar un valor en un arbol binario ordenado
2. insertar un valor en un arbol binario ordenado
3. recorrido en inorden
4. recorrido en proorden
5. recorrido en postorden
6. insertar lista de valores en un arbol binario ordenado
