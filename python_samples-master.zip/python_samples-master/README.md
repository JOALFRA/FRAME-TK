# Ejemplos de código en python

Algunos ejemplos de diferentes ejercicio desarrollados usando python
