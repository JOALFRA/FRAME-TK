from juego import *

lista = crear_lista(input("ingrese el tamano"))

jugar(4,lista)
