# Ejemplo de flask y sqlite3 con python
