# estructuras

ejemplos de las estructuras básicas:
1. pilas
2. colas
3. árboles 
